#!/bin/sh
id > /tmp/pwned
